require('../utils/message_code');
require('../utils/error_code');
require('../utils/constants');
var console = require('../utils/console');

var Order = require('mongoose').model('order');
var Provider = require('mongoose').model('provider');
var Request = require('mongoose').model('request');
var console = require('../utils/console');

var utils = require('../utils/utils');

// Today orders order_lists_search_sort
exports.order_lists_search_sort = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            var user_query = {
                $lookup:
                        {
                            from: "users",
                            localField: "user_id",
                            foreignField: "_id",
                            as: "user_detail"
                        }
            };
            var array_to_json_user_detail = {$unwind: "$user_detail"};
            var store_query = {
                $lookup:
                        {
                            from: "stores",
                            localField: "store_id",
                            foreignField: "_id",
                            as: "store_detail"
                        }
            };
            var array_to_json_store_detail = {$unwind: {
                                    path: "$store_detail",
                                    preserveNullAndEmptyArrays: true
                                }
                            };

            var city_query = {
                $lookup:
                        {
                            from: "cities",
                            localField: "city_id",
                            foreignField: "_id",
                            as: "city_detail"
                        }
            };
            var array_to_json_city_query = {$unwind: "$city_detail"};
            var order_payment_query = {
                $lookup:
                        {
                            from: "order_payments",
                            localField: "order_payment_id",
                            foreignField: "_id",
                            as: "order_payment_detail"
                        }
            };
            var array_to_json_order_payment_query = {$unwind: "$order_payment_detail"};



            var payment_gateway_query = {
                $lookup:
                        {
                            from: "payment_gateways",
                            localField: "order_payment_detail.payment_id",
                            foreignField: "_id",
                            as: "payment_gateway_detail"
                        }
            };

            var number_of_rec = SEARCH_SORT.NO_OF_RECORD_PER_PAGE;
            var page = request_data_body.page;
            var search_field = request_data_body.search_field;
            var search_value = request_data_body.search_value;

            if (search_field === "user_detail.first_name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['user_detail.last_name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['user_detail.last_name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field === "store_detail.name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['store_detail.name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['store_detail.name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field == 'unique_id')
            {
                var query = {};
                if (search_value !== "")
                {
                    search_value = Number(search_value);
                    query[search_field] = search_value;
                    var search = {"$match": query};
                }
            } else
            {
                var query = {};
                query[search_field] = {$regex: new RegExp(search_value, 'i')};
                var search = {"$match": query};
            }

            var sort = {"$sort": {}};
            sort["$sort"]['unique_id'] = parseInt(-1);
            var count = {$group: {_id: null, total: {$sum: 1}, data: {$push: '$data'}}};
            var skip = {};
            skip["$skip"] = (page * number_of_rec) - number_of_rec;
            var limit = {};
            limit["$limit"] = number_of_rec;

            var condition = {$match: {}};
            var date = new Date(Date.now()).toLocaleString("en-US", {timeZone: setting_detail.admin_panel_timezone});
            date = new Date(date);
            date = date.setHours(0, 0, 0, 0);
            startdate = new Date(date);
            enddate = new Date(Date.now()).toLocaleString("en-US", {timeZone: setting_detail.admin_panel_timezone});

            enddate = new Date(enddate);
            condition = {$match: {'created_at': {$gte: startdate, $lt: enddate}}};

            Order.aggregate([condition, user_query, order_payment_query, store_query, city_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_gateway_query
                        , search, count]).then((orders) => {
                
                if (orders.length === 0)
                {
                    response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND, pages: 0});
                } else
                {

                    var timezone = "";
                    if (setting_detail)
                    {
                        timezone = setting_detail.admin_panel_timezone;
                    }
                    var pages = Math.ceil(orders[0].total / number_of_rec);
                    if (page)
                    {
                        Order.aggregate([condition, user_query, order_payment_query, store_query, city_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_gateway_query
                                    , sort, search, skip, limit]).then((orders) => {
                            if (orders.length === 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else
                            {

                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY, pages: pages,
                                    orders: orders,
                                    timezone: timezone});
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    } else
                    {
                        Order.aggregate([condition, user_query, order_payment_query, store_query, city_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_gateway_query
                                    , sort, search]).then((orders) => {
                            if (orders.length === 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else
                            {

                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY, pages: pages,
                                    orders: orders,
                                    timezone: timezone});
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    }
                }
            }, (error) => {
                console.log(error)
                response_data.json({
                    success: false,
                    error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                });
            });
        } else {
            response_data.json(response);
        }
    });
};
exports.orders_list_export = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            var user_query = {
                $lookup:
                        {
                            from: "users",
                            localField: "user_id",
                            foreignField: "_id",
                            as: "user_detail"
                        }
            };
            var array_to_json_user_detail = {$unwind: "$user_detail"};
            var store_query = {
                $lookup:
                        {
                            from: "stores",
                            localField: "store_id",
                            foreignField: "_id",
                            as: "store_detail"
                        }
            };
            var array_to_json_store_detail = {$unwind: {
                                    path: "$store_detail",
                                    preserveNullAndEmptyArrays: true
                                }
                            };
            var cart_query = {
                $lookup:
                    {
                        from: "carts",
                        localField: "cart_id",
                        foreignField: "_id",
                        as: "cart_detail"
                    }
            };
            var array_to_json_cart_query = {$unwind: "$cart_detail"};
            var city_query = {
                $lookup:
                        {
                            from: "cities",
                            localField: "city_id",
                            foreignField: "_id",
                            as: "city_detail"
                        }
            };
            var array_to_json_city_query = {$unwind: "$city_detail"};
            var order_payment_query = {
                $lookup:
                        {
                            from: "order_payments",
                            localField: "order_payment_id",
                            foreignField: "_id",
                            as: "order_payment_detail"
                        }
            };
            var array_to_json_order_payment_query = {$unwind: "$order_payment_detail"};
            var payment_gateway_query = {
                $lookup:
                        {
                            from: "payment_gateways",
                            localField: "order_payment_detail.payment_id",
                            foreignField: "_id",
                            as: "payment_gateway_detail"
                        }
            };


            var number_of_rec = SEARCH_SORT.NO_OF_RECORD_PER_PAGE;
            var page = request_data_body.page;
            if(request_data_body.search_field == "user_detail.name"){
                request_data_body.search_field ="user_detail.first_name";
            }
            var search_field = request_data_body.search_field;
            var search_value = request_data_body.search_value;


            if (search_field === "user_detail.first_name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['user_detail.last_name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['user_detail.last_name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field === "store_detail.name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['store_detail.name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['store_detail.name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field == 'unique_id')
            {
                var query = {};
                if (search_value !== "")
                {
                    search_value = Number(search_value);
                    query[search_field] = search_value;
                    var search = {"$match": query};
                }
            } else
            {
                var query = {};
                query[search_field] = {$regex: new RegExp(search_value, 'i')};
                var search = {"$match": query};
            }

            var sort = {"$sort": {}};
            sort["$sort"]["unique_id"] = parseInt(-1);
            var count = {$group: {_id: null, total: {$sum: 1}, data: {$push: '$data'}}};
            var skip = {};
            skip["$skip"] = (page * number_of_rec) - number_of_rec;
            var limit = {};
            limit["$limit"] = number_of_rec;

            // var order_condition = {$match: {$and: [ {$or: [ {'order_status_id': {$eq: ORDER_STATUS_ID.RUNNING}} , {'order_status_id': {$eq: ORDER_STATUS_ID.IDEAL}} ]} ,{'order_status_manage_id': {$ne: ORDER_STATUS_ID.COMPLETED}} ]}};
            var order_condition = {$match: {$and: [ {$or: [ {'order_status_id': {$eq: ORDER_STATUS_ID.RUNNING}} , {'order_status_id': {$eq: ORDER_STATUS_ID.IDEAL}} ]} ,{$or: [{'order_status_manage_id': {$ne: ORDER_STATUS_ID.COMPLETED}}, {'request_id': {$eq: null}}]} ]}};

            var request_status_condition = {$match: {}}
            if(request_data_body.order_status != 'all'){
                request_status_condition = {"$match": {'order_status': {$eq: Number(request_data_body.order_status)}}};
            }
            var payment_status_condition = {$match: {}}
            if(request_data_body.payment_status != 'all'){
                if(request_data_body.payment_status == 'true'){
                    payment_status_condition = {"$match": {'order_payment_detail.is_payment_mode_cash': {$eq: true}}};
                } else {
                    payment_status_condition = {"$match": {'order_payment_detail.is_payment_mode_cash': {$eq: false}}};
                }
            }

            var pickup_type = request_data_body.pickup_type;
            var pickup_type_condition = {$match: {}}
            if(pickup_type != 'both'){
                if(request_data_body.pickup_type == 'true'){
                    payment_status_condition = {"$match": {'order_payment_detail.is_user_pick_up_order': {$eq: true}}};
                } else {
                    payment_status_condition = {"$match": {'order_payment_detail.is_user_pick_up_order': {$eq: false}}};
                }
            }

            var created_by = request_data_body.created_by;
            var created_by_condition = {$match: {}}
            if(created_by != 'both'){
                created_by_condition = {"$match": {'order_type': {$eq: Number(created_by)}}};
            }

            var order_type = request_data_body.order_type;
            var order_type_condition = {$match: {}}
            if(order_type != 'both'){
                if(request_data_body.order_type == 'true'){
                    order_type_condition = {"$match": {'is_schedule_order': {$eq: true}}};
                } else {
                    order_type_condition = {"$match": {'is_schedule_order': {$eq: false}}};
                }
            }

            Order.aggregate([order_condition, created_by_condition, order_type_condition, user_query, request_status_condition, order_payment_query, store_query, cart_query, array_to_json_cart_query, city_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_status_condition, pickup_type_condition, payment_gateway_query
                        , search
                        , count
            ]).then((orders) => {

                if (orders.length === 0)
                {
                    response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND, pages: 0});
                } else
                {
                    var timezone = "";
                    if (setting_detail)
                    {
                        timezone = setting_detail.admin_panel_timezone;
                    }
                    var pages = Math.ceil(orders[0].total / number_of_rec);
                    if (page)
                    {
                        Order.aggregate([order_condition, created_by_condition, order_type_condition, user_query, request_status_condition, order_payment_query, store_query, city_query, cart_query, array_to_json_cart_query,  array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_status_condition, pickup_type_condition, payment_gateway_query

                                    , sort, search, skip, limit
                        ]).then((orders) => {
                            if (orders.length == 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else
                            {
                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY, pages: pages,
                                    orders: orders,
                                    timezone: timezone});
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    } else {
                        Order.aggregate([order_condition, created_by_condition, order_type_condition, request_status_condition, user_query, order_payment_query, store_query, city_query, cart_query, array_to_json_cart_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_status_condition, pickup_type_condition, payment_gateway_query
                            , sort, search
                        ]).then((orders) => {
                            if (orders.length == 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else {
                                response_data.json({
                                    success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY, pages: pages,
                                    orders: orders,
                                    timezone: timezone
                                });
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    }
                }
            }, (error) => {
                console.log(error)
                response_data.json({
                    success: false,
                    error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                });
            });
        } else {
            response_data.json(response);
        }
    });
};

// admin_orders
exports.admin_orders = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            
            var number_of_rec = Number(request_data_body.no_of_records);
            var page = request_data_body.page;

            /*var search_field = request_data_body.search_field;
            var search_value = request_data_body.search_value;*/
            var query1 = {};
            var query2 = {};
            var query3 = {};


            
                if (request_data_body.user_name !== "")
                {    
                    request_data_body.user_name = request_data_body.user_name.replace(/^\s+|\s+$/g, '');
                    request_data_body.user_name = request_data_body.user_name.replace(/ +(?= )/g, '');
                   
                    query1['user_detail.name'] = {$regex: new RegExp(request_data_body.user_name, 'i')};
                    
                }
                if (request_data_body.store_name !== "")
                {    
                    request_data_body.store_name = request_data_body.store_name.replace(/^\s+|\s+$/g, '');
                    request_data_body.store_name = request_data_body.store_name.replace(/ +(?= )/g, '');
                   
                    query2['store_detail.name'] = {$regex: new RegExp(request_data_body.store_name, 'i')};
                   
                }
                if (request_data_body.unique_id && request_data_body.unique_id !== "")
                {    
                   
                    query3['unique_id'] = Number(request_data_body.unique_id);
                   
                }
            
                 var search = {"$match": {$and: [query1, query2, query3]}};
                
            var sort = {"$sort": {}};
            sort["$sort"]["unique_id"] = parseInt(-1);
            var count = {$group: {_id: null, total: {$sum: 1}, data: {$push: '$data'}}};
            var skip = {};
            skip["$skip"] = (page * number_of_rec) - number_of_rec;
            var limit = {};
            limit["$limit"] = number_of_rec;

            // var order_condition = {$match: {$and: [ {$or: [ {'order_status_id': {$eq: ORDER_STATUS_ID.RUNNING}} , {'order_status_id': {$eq: ORDER_STATUS_ID.IDEAL}} ]} ,{'order_status_manage_id': {$ne: ORDER_STATUS_ID.COMPLETED}} ]}};
            var order_condition = {$match: {$and: [ {$or: [ {'order_status_id': {$eq: ORDER_STATUS_ID.RUNNING}} , {'order_status_id': {$eq: ORDER_STATUS_ID.IDEAL}} ]} ,{$or: [{'order_status_manage_id': {$ne: ORDER_STATUS_ID.COMPLETED}}, {'request_id': {$eq: null}}]} ]}};

            var request_status_condition = {$match: {}}
            if(request_data_body.order_status != 'all'){
                request_status_condition = {"$match": {'order_status': {$eq: Number(request_data_body.order_status)}}};
            }
            var payment_status_condition = {$match: {}}
            if(request_data_body.payment_status != 'all'){
                if(request_data_body.payment_status == 'true'){
                    payment_status_condition = {"$match": {'is_payment_mode_cash': {$eq: true}}};
                } else {
                    payment_status_condition = {"$match": {'is_payment_mode_cash': {$eq: false}}};
                }
            }

            var pickup_type = request_data_body.pickup_type;
            var pickup_type_condition = {$match: {}}
            if(pickup_type != 'both'){
                if(request_data_body.pickup_type == 'true'){
                    payment_status_condition = {"$match": {'is_user_pick_up_order': {$eq: true}}};
                } else {
                    payment_status_condition = {"$match": {'is_user_pick_up_order': {$eq: false}}};
                }
            }

            var created_by = request_data_body.created_by;
            var created_by_condition = {$match: {}}
            if(created_by != 'both'){
                created_by_condition = {"$match": {'order_type': {$eq: Number(created_by)}}};
            }

            var order_type = request_data_body.order_type;
            var order_type_condition = {$match: {}}
            if(order_type != 'both'){
                if(request_data_body.order_type == 'true'){
                    order_type_condition = {"$match": {'is_schedule_order': {$eq: true}}};
                } else {
                    order_type_condition = {"$match": {'is_schedule_order': {$eq: false}}};
                }
            }
            if (request_data_body.start_date == '' || request_data_body.end_date == '') {
                if (request_data_body.start_date == '' && request_data_body.end_date == '') {
                    var date = new Date(Date.now());
                    date = date.setHours(0, 0, 0, 0);
                    start_date = new Date(0);
                    end_date = new Date(Date.now());
                } else if (request_data_body.start_date == '') {
                    start_date = new Date(0);
                    var end_date = request_data_body.end_date.formatted;
                    end_date = new Date(end_date);
                    end_date = end_date.setHours(23, 59, 59, 999);
                    end_date = new Date(end_date);
                } else {
                    var start_date = request_data_body.start_date.formatted;
                    start_date = new Date(start_date);
                    start_date = start_date.setHours(0, 0, 0, 0);
                    start_date = new Date(start_date);
                    end_date = new Date(Date.now());
                }
            } else {

                var start_date = request_data_body.start_date.formatted;
                var end_date = request_data_body.end_date.formatted;

                start_date = new Date(start_date);
                start_date = start_date.setHours(0, 0, 0, 0);
                start_date = new Date(start_date);
                end_date = new Date(end_date);
                end_date = end_date.setHours(23, 59, 59, 999);
                end_date = new Date(end_date);
            }
            var filter = {"$match": {"created_at": {$gte: start_date, $lt: end_date}}};
            var project = {$project: {is_schedule_order: "$is_schedule_order",
                                            unique_id: "$unique_id",
                                            schedule_order_start_at: "$schedule_order_start_at",
                                            created_at: "$created_at",
                                            user_detail: "$user_detail",
                                            store_detail: "$store_detail",
                                            order_status: "$order_status",
                                            is_paid_from_wallet: "$is_paid_from_wallet",
                                            user_id: "$user_id",
                                            total: "$total",
                                            is_payment_mode_cash: "$is_payment_mode_cash"
                                        }
                                    }

            
                    var timezone = "";
                    if (setting_detail)
                    {
                        timezone = setting_detail.admin_panel_timezone;
                    }
                    
                    if (page)
                    {
                        Order.aggregate([filter,order_condition, created_by_condition, order_type_condition,  request_status_condition,payment_status_condition, pickup_type_condition,project, sort, search, skip, limit
                        ]).then((orders) => {
                            if (orders.length == 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else
                            {
                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY,
                                    orders: orders,
                                    timezone: timezone});
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    } else {
                        Order.aggregate([filter,order_condition, created_by_condition, order_type_condition, request_status_condition,payment_status_condition, pickup_type_condition, sort, search
                        ]).then((orders) => {
                            if (orders.length == 0) {
                                response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND});
                            } else {
                                response_data.json({
                                    success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY,
                                    orders: orders,
                                    timezone: timezone
                                });
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    }
                
        } else {
            response_data.json(response);
        }
    });
};
exports.admin_orders_detail = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {
            var User = require('mongoose').model('user');
            var Store = require('mongoose').model('store');
            var Cart = require('mongoose').model('cart');
            var Order_payment = require('mongoose').model('order_payment');
            var request_data_body = request_data.body;
            Order.findOne({_id:request_data_body.order_detail_id},function(err,order_detail){
                User.findOne({_id:order_detail.user_id},function(err,user_detail){
                    Store.findOne({_id:order_detail.store_id},function(err,store_detail){
                        Order_payment.findOne({_id:order_detail.order_payment_id},function(err,order_payment_detail){
                            Cart.findOne({_id:order_detail.cart_id},function(err,cart_detail){
                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY,
                                    user_detail: user_detail,
                                    store_detail: store_detail,
                                    order_payment_detail: order_payment_detail,
                                    order_detail: order_detail,
                                    cart_detail: cart_detail});
                            })
                        })
                    })
                })
            })
            
        } else {
            response_data.json(response);
        }
    });
};
// deliveryman_track
exports.deliveryman_track = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [{name: 'id', type: 'string'}], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            var id = request_data_body.id;
            var type = Number(request_data_body.type);
            if (type == 1)
            {
                Order.findOne({_id: id}).then((order_detail) => {
                    if (order_detail)
                    {
                        Request.findOne({_id: order_detail.request_id}).then((request) => {
                            if (request)
                            {
                                console.log(order_detail.request_id);
                                Provider.findOne({_id: request.current_provider}).then((provider_detail) => {
                                    if (provider_detail) {
                                        response_data.json({
                                            success: true,
                                            message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY,
                                            provider: provider_detail

                                        });
                                    } else
                                    {
                                        response_data.json({
                                            success: false,
                                            message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY


                                        });
                                    }
                                }, (error) => {
                                    console.log(error)
                                    response_data.json({
                                        success: false,
                                        error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                                    });
                                });
                            } else
                            {
                                response_data.json({
                                    success: false,
                                    message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY
                                });
                            }
                        }, (error) => {
                            console.log(error)
                            response_data.json({
                                success: false,
                                error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                            });
                        });
                    } else
                    {
                        response_data.json({
                            success: false,
                            message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY
                        });
                    }
                }, (error) => {
                    console.log(error)
                    response_data.json({
                        success: false,
                        error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                    });
                });
            } else
            {
                Provider.findOne({_id: id}).then((provider_detail) => {
                    console.log("pass provider_id provider_detail");
                    response_data.json({
                        success: true,
                        message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY,
                        provider: provider_detail

                    });
                }, (error) => {
                    console.log(error)
                    response_data.json({
                        success: false,
                        error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                    });
                });
            }
        } else {
            response_data.json(response);
        }
    });
};

// order_list_location_track
exports.order_list_location_track = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            Order.find({city_id: request_data_body.city_id, order_status_id: ORDER_STATUS_ID.RUNNING}).then((orders) => {
                if (orders.length == 0)
                {
                    response_data.json({
                        success: false,
                        message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY
                    });
                } else
                {
                    response_data.json({
                        success: true,
                        message: ORDER_MESSAGE_CODE.ORDER_CANCEL_OR_REJECT_BY_PROVIDER_SUCCESSFULLY,
                        orders: orders

                    });
                }
            }, (error) => {
                console.log(error)
                response_data.json({
                    success: false,
                    error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                });
            });
        } else {
            response_data.json(response);
        }
    });
};

////////////
// orders_list_export_excel
exports.orders_list_export_excel = function (request_data, response_data) {
    utils.check_request_params(request_data.body, [], function (response) {
        if (response.success) {

            var request_data_body = request_data.body;
            var user_query = {
                $lookup:
                        {
                            from: "users",
                            localField: "user_id",
                            foreignField: "_id",
                            as: "user_detail"
                        }
            };
            var array_to_json_user_detail = {$unwind: "$user_detail"};
            var store_query = {
                $lookup:
                        {
                            from: "stores",
                            localField: "store_id",
                            foreignField: "_id",
                            as: "store_detail"
                        }
            };
            var array_to_json_store_detail = {$unwind: {
                                    path: "$store_detail",
                                    preserveNullAndEmptyArrays: true
                                }
                            };

            var city_query = {
                $lookup:
                        {
                            from: "cities",
                            localField: "city_id",
                            foreignField: "_id",
                            as: "city_detail"
                        }
            };
            var array_to_json_city_query = {$unwind: "$city_detail"};

            var order_payment_query = {
                $lookup:
                        {
                            from: "order_payments",
                            localField: "order_payment_id",
                            foreignField: "_id",
                            as: "order_payment_detail"
                        }
            };
            var array_to_json_order_payment_query = {$unwind: "$order_payment_detail"};

            var payment_gateway_query = {
                $lookup:
                        {
                            from: "payment_gateways",
                            localField: "order_payment_detail.payment_id",
                            foreignField: "_id",
                            as: "payment_gateway_detail"
                        }
            };


            var number_of_rec = SEARCH_SORT.NO_OF_RECORD_PER_PAGE;
            var page = request_data_body.page;

            var sort_field = request_data_body.sort_field;
            var sort_order = request_data_body.sort_order;
            var search_field = request_data_body.search_field;
            var search_value = request_data_body.search_value;


            if (search_field === "user_detail.first_name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['user_detail.last_name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['user_detail.last_name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['user_detail.last_name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field === "store_detail.name")
            {
                search_value = search_value.replace(/^\s+|\s+$/g, '');
                search_value = search_value.replace(/ +(?= )/g, '');
                var query1 = {};
                var query2 = {};
                var query3 = {};
                var query4 = {};
                var query5 = {};
                var query6 = {};
                var full_name = search_value.split(' ');
                if (typeof full_name[0] === 'undefined' || typeof full_name[1] === 'undefined') {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    var search = {"$match": {$or: [query1, query2]}};
                } else {

                    query1[search_field] = {$regex: new RegExp(search_value, 'i')};
                    query2['store_detail.name'] = {$regex: new RegExp(search_value, 'i')};
                    query3[search_field] = {$regex: new RegExp(full_name[0], 'i')};
                    query4['store_detail.name'] = {$regex: new RegExp(full_name[0], 'i')};
                    query5[search_field] = {$regex: new RegExp(full_name[1], 'i')};
                    query6['store_detail.name'] = {$regex: new RegExp(full_name[1], 'i')};
                    var search = {"$match": {$or: [query1, query2, query3, query4, query5, query6]}};
                }
            } else if (search_field == 'unique_id')
            {
                var query = {};
                if (search_value !== "")
                {
                    search_value = Number(search_value);
                    query[search_field] = search_value;
                    var search = {"$match": query};
                }
            } else
            {
                var query = {};
                query[search_field] = {$regex: new RegExp(search_value, 'i')};
                var search = {"$match": query};
            }

            var sort = {"$sort": {}};
            sort["$sort"][sort_field] = parseInt(sort_order);
            var count = {$group: {_id: null, total: {$sum: 1}, data: {$push: '$data'}}};
            var skip = {};
            skip["$skip"] = (page * number_of_rec) - number_of_rec;
            var limit = {};
            limit["$limit"] = number_of_rec;

            var order_condition = {"$match": {'order_status_id': {$ne: ORDER_STATUS_ID.COMPLETED}}};

            var group = {$group: {
                    _id: null,
                    data: {$push: {
                            user_first_name: "$user_detail.first_name",
                            user_last_name: "$user_detail.last_name",
                            store: '$store_detail.name',
                            city: "$city_detail.city_name",
                            amount: "$order_payment_detail.total",
                            payment_status: "$order_payment_detail.is_payment_mode_cash",
                            date: "$created_at"
                        }}
                }
            };
            var project = {$project: {data: 1}}


            Order.aggregate([order_condition, user_query, order_payment_query, store_query, city_query, array_to_json_user_detail, array_to_json_store_detail, array_to_json_city_query, array_to_json_order_payment_query, payment_gateway_query
                        , search, group, project

            ]).then((orders) => {

                if (orders.length === 0)
                {
                    response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND, pages: 0});
                } else
                {

                    var json_data = [];
                    if (orders[0].data.length > 0) {
                        var order_data = orders[0].data;
                        for (var i = 0; i < order_data.length; ) {
                            var city = '';
                            city = order_data[i].city;


                            json_data.push({
                                "User": order_data[i].user_first_name + " " + order_data[i].user_last_name,
                                "Store": order_data[i].store,
                                "City": city,
                                "Amount": order_data[i].amount,
                                "Date": order_data[i].date
                            });
                            i++;
                            if (orders[0].data.length == i) {
                                response_data.json({success: true,
                                    message: ORDER_MESSAGE_CODE.ORDER_LIST_SUCCESSFULLY,
                                    orders: json_data});
                            }
                        }
                    } else {
                        response_data.json({success: false, error_code: ORDER_ERROR_CODE.ORDER_NOT_FOUND, pages: 0});
                    }
                }
            }, (error) => {
                console.log(error)
                response_data.json({
                    success: false,
                    error_code: ERROR_CODE.SOMETHING_WENT_WRONG
                });
            });
        } else {
            response_data.json(response);
        }
    });
};